f = open("file","w")
for i in range(0,100000):
    f.write(str(i)+"\n")
    pass